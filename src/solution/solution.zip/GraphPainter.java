package solution;

import scotlandyard.*;

import java.io.*;
import java.util.*;

import javax.imageio.*;
import java.awt.image.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;

public class GraphPainter
{
    public static void main(String[] args) throws IOException
    {
        String dir = "../../resources/dist/";
        
        ScotlandYardGraphReader r = new ScotlandYardGraphReader();
        Graph<Integer,Route> graph = r.readGraph(dir + args[0]);
        
        Point[] ls = new Point[199];
        Scanner nodeScanner = new Scanner(new File(dir + args[1]));
        while (nodeScanner.hasNextLine())
        {
            String[] parts = nodeScanner.nextLine().split(" ");
            int i = Integer.parseInt(parts[0]) - 1;
            int x = Integer.parseInt(parts[1]);
            int y = Integer.parseInt(parts[2]);
            ls[i] = new Point(x, y);
        }
        
        System.err.println("Graph and nodes loaded.");
        
        BufferedImage img;
        BufferedImage taxi = new BufferedImage(5625, 4655, BufferedImage.TYPE_INT_ARGB);
        BufferedImage bus = new BufferedImage(5625, 4655, BufferedImage.TYPE_INT_ARGB);
        BufferedImage tube = new BufferedImage(5625, 4655, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d;
        BasicStroke s = new BasicStroke(10);
        
        int n1, n2;
        for (Edge<Integer,Route> e : graph.getEdges())
        {
            if (e.data() == Route.Boat) continue;
            n1 = e.source();
            n2 = e.target();
            if      (e.data() == Route.Taxi) img = taxi;
            else if (e.data() == Route.Bus)  img = bus;
            else                             img = tube;
            
            g2d = (Graphics2D)img.getGraphics();
            g2d.setColor(Color.BLACK);
            g2d.setStroke(s);
            g2d.drawLine(ls[n1-1].x, ls[n1-1].y, ls[n2-1].x, ls[n2-1].y);
        }
        
        File outT = new File(dir + args[2] + "-taxi.png");
        File outB = new File(dir + args[2] + "-bus.png");
        File outU = new File(dir + args[2] + "-tube.png");
        ImageIO.write(taxi, "png", outT);
        ImageIO.write(bus,  "png", outB);
        ImageIO.write(tube, "png", outU);
    }
}





